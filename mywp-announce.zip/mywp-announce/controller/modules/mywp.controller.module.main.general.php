<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if( ! class_exists( 'MywpControllerAbstractModule' ) ) {
  return false;
}

if ( ! class_exists( 'MywpControllerModuleAnnounceMainGeneral' ) ) :

final class MywpControllerModuleAnnounceMainGeneral extends MywpControllerAbstractModule {

  static protected $id = 'announce_main_general';

  static protected $is_do_controller = true;

  protected static function after_init() {

    add_filter( 'mywp_controller_pre_get_model_' . self::$id , array( __CLASS__ , 'mywp_controller_pre_get_model' ) );

  }

  public static function mywp_controller_pre_get_model( $pre_model ) {

    $pre_model = true;

    return $pre_model;

  }

  public static function mywp_wp_loaded() {

    if( ! is_admin() ) {

      return false;

    }

    add_action( 'load-plugins.php' , array( __CLASS__ , 'load_plugins' ) );

  }

  private static function is_current_plugin( $plugin_file_name = false ) {

    if( empty( $plugin_file_name ) ) {

      return false;

    }

    $plugin_file_name = MywpHelper::sanitize_text( $plugin_file_name );

    if( strpos( MYWP_ANNOUNCE_PLUGIN_BASENAME , $plugin_file_name ) === false ) {

      return false;

    }

    return true;

  }

  public static function load_plugins() {

    add_filter( 'plugin_row_meta' , array( __CLASS__ , 'plugin_row_meta' ) , 10 , 4 );

    add_filter( 'network_admin_plugin_action_links_' . MYWP_ANNOUNCE_PLUGIN_BASENAME , array( __CLASS__ , 'plugin_action_links' ) , 10 , 4 );

    add_filter( 'plugin_action_links_' . MYWP_ANNOUNCE_PLUGIN_BASENAME , array( __CLASS__ , 'plugin_action_links' ) , 10 , 4 );

    //add_action( 'in_plugin_update_message-' . MYWP_ANNOUNCE_PLUGIN_BASENAME , array( __CLASS__ , 'in_plugin_update_message' ) , 10 , 2 );

    //add_action( 'admin_print_footer_scripts' , array( __CLASS__ , 'admin_print_footer_scripts' ) );

  }

  public static function plugin_row_meta( $plugin_meta , $plugin_file , $plugin_data , $status ) {

    if( ! self::is_current_plugin( $plugin_file ) ) {

      return $plugin_meta;

    }

    $plugin_info = MywpAnnounceApi::plugin_info();

    if( ! empty( $plugin_info['document_url'] ) ) {

      $plugin_meta[] =  sprintf( '<a href="%1$s" target="_blank">%2$s</a>' , esc_url( $plugin_info['document_url'] ) , esc_html( __( 'Documents' , 'my-wp' ) ) );

    }

    $plugin_meta = apply_filters( 'mywp_announce_plugin_row_meta' , $plugin_meta , $plugin_file , $plugin_data , $status );

    return $plugin_meta;

  }

  public static function plugin_action_links( $actions , $plugin_file , $plugin_data , $context ) {

    if( ! self::is_current_plugin( $plugin_file ) ) {

      return $actions;

    }

    $plugin_info = MywpAnnounceApi::plugin_info();

    if( is_multisite() && is_network_admin() ) {

      if( ! empty( $plugin_info['network_admin_url'] ) ) {

        $action_link = array( 'setting' => sprintf( '<a href="%1$s">%2$s</a>' , esc_url( $plugin_info['network_admin_url'] ) , esc_html( __( 'Settings' ) ) ) );

        $actions = wp_parse_args( $actions , $action_link );

      }

    } else {

      if( ! empty( $plugin_info['admin_url'] ) ) {

        $action_link = array( 'setting' => sprintf( '<a href="%1$s">%2$s</a>' , esc_url( $plugin_info['admin_url'] ) , esc_html( __( 'Settings' ) ) ) );

        $actions = wp_parse_args( $actions , $action_link );

      }

    }

    $actions = apply_filters( 'mywp_announce_plugin_action_links' , $actions , $plugin_file , $plugin_data , $context );

    return $actions;

  }

  /*
  public static function in_plugin_update_message( $plugin_data , $response ) {

    if( empty( $response->new_version ) ) {

      return false;

    }

    echo '</p>';

    echo '<p class="show">';

    $plugin_info = MywpAnnounceApi::plugin_info();

    echo sprintf( __( 'There is a new version of %1$s available. <a href="%2$s" target="_blank">View version %3$s details</a>.' ) , esc_html( $response->new_version ) , esc_url( $plugin_info['github'] ) , esc_html( MYWP_ANNOUNCE_NAME ) );

  }

  public static function admin_print_footer_scripts() {

    echo '<style>';

    echo sprintf( 'tr#%s-update .update-message p { display: none; }' , esc_html( MYWP_ANNOUNCE_PLUGIN_DIRNAME ) );
    echo sprintf( 'tr#%s-update .update-message p.show { display: block; }' , esc_html( MYWP_ANNOUNCE_PLUGIN_DIRNAME ) );

    echo '</style>';

  }
  */

}

MywpControllerModuleAnnounceMainGeneral::init();

endif;
